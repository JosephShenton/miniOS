//
//  FadeSegue.h
//  miniOS
//
//  Created by Joseph on 18/3/17.
//  Copyright © 2017 JJS Digital PTY LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FadeSegue2 : UIStoryboardSegue

@end
