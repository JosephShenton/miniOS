//
//  DesktopViewController.m
//  miniOS
//
//  Created by Joseph on 18/3/17.
//  Copyright © 2017 JJS Digital PTY LTD. All rights reserved.
//

#import "DesktopViewController.h"

@interface DesktopViewController ()
@property (weak, nonatomic) IBOutlet UIView *dockBar;
@property (weak, nonatomic) IBOutlet UILabel *dntLabel;
@property (weak, nonatomic) IBOutlet UILabel *chargingLabel;
@property (weak, nonatomic) IBOutlet UIImageView *chargingIcon;
@property (weak, nonatomic) IBOutlet UIButton *notePadCloseIcon;
@property (weak, nonatomic) IBOutlet UILabel *notepadStatusBarName;
@property (weak, nonatomic) IBOutlet UIView *notePadApp;
@property (weak, nonatomic) IBOutlet UITextView *notepadtextview;
@property (weak, nonatomic) IBOutlet UIView *notePadAppDragger;
@property (weak, nonatomic) IBOutlet UIView *webbrowserApp;
@property (weak, nonatomic) IBOutlet UILabel *webbrowserStatusBarName;
@property (weak, nonatomic) IBOutlet UIView *webBrowserAppDragger;
@property (weak, nonatomic) IBOutlet UIWebView *browser;
@property (weak, nonatomic) IBOutlet UIButton *webBrowserCloseIcon;
@property (weak, nonatomic) IBOutlet UITextField *urlBar;
@property (weak, nonatomic) IBOutlet UIView *settingsApp;
@property (weak, nonatomic) IBOutlet UILabel *settingsStatusBarLabel;
@property (weak, nonatomic) IBOutlet UIButton *settingCloseButton;
@property (weak, nonatomic) IBOutlet UIView *settingsAppDragger;
@property (weak, nonatomic) IBOutlet UILabel *darkModeText;
@property (weak, nonatomic) IBOutlet UIView *statusBar;

@end

@implementation DesktopViewController

UIView* loadingView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _notePadCloseIcon.layer.masksToBounds = true;
    _notePadCloseIcon.layer.cornerRadius = 11;
    _webBrowserCloseIcon.layer.masksToBounds = true;
    _webBrowserCloseIcon.layer.cornerRadius = 11;
    _settingCloseButton.layer.masksToBounds = true;
    _settingCloseButton.layer.cornerRadius = 11;
    _dockBar.layer.cornerRadius = 3.6;
    _dockBar.layer.masksToBounds = YES;
    _notePadApp.layer.cornerRadius = 3.6;
    _notePadApp.layer.masksToBounds = YES;
    _webbrowserApp.layer.cornerRadius = 3.6;
    _webbrowserApp.layer.masksToBounds = YES;
    _settingsApp.layer.cornerRadius = 3.6;
    _settingsApp.layer.masksToBounds = YES;
    NSDate *today = [NSDate date];
    NSDateFormatter *weekdayFormatter = [[NSDateFormatter alloc] init];
    [weekdayFormatter setDateFormat: @"EEE"];
    NSString *weekday = [weekdayFormatter stringFromDate: today];
    NSDate * now = [NSDate date];
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:@"HH:mm a"];
    NSString *newDateString = [outputFormatter stringFromDate:now];
    //_time.text = newDateString;
    _dntLabel.text = [NSString stringWithFormat:@"%@. %@", weekday, newDateString];

    NSLog(@"newDateString %@", newDateString);
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(changeClock) userInfo:nil repeats: YES];
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(checkBattery) userInfo:nil repeats: YES];
    
    [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
    float batteryLevel = [[UIDevice currentDevice] batteryLevel];
    
    batteryLevel *= 100;
    NSString *percentSign = @"%";
    _chargingLabel.text = [NSString stringWithFormat:@"%.0f%@", batteryLevel, percentSign];
    UIDeviceBatteryState deviceBatteryState = [UIDevice currentDevice].batteryState;
    if (deviceBatteryState == UIDeviceBatteryStateCharging || deviceBatteryState == UIDeviceBatteryStateFull) {
        _chargingIcon.hidden = false;
    } else {
        _chargingIcon.hidden = true;
    }
    [_notepadtextview setDelegate:self];
    NSString *urlString = @"https://google.com";
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [_browser loadRequest:urlRequest];
    _browser.delegate = self;
    loadingView = [[UIView alloc]initWithFrame:CGRectMake(100, 400, 80, 80)];
    loadingView.backgroundColor = [UIColor colorWithWhite:0. alpha:0.6];
    loadingView.layer.cornerRadius = 5;
    
    UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activityView.center = CGPointMake(loadingView.frame.size.width / 2.0, 35);
    [activityView startAnimating];
    activityView.tag = 100;
    [loadingView addSubview:activityView];
    
    UILabel* lblLoading = [[UILabel alloc]initWithFrame:CGRectMake(0, 48, 80, 30)];
    lblLoading.text = @"Loading...";
    lblLoading.textColor = [UIColor whiteColor];
    lblLoading.font = [UIFont fontWithName:lblLoading.font.fontName size:15];
    lblLoading.textAlignment = NSTextAlignmentCenter;
    [loadingView addSubview:lblLoading];
    
    [self.view addSubview:loadingView];
    [loadingView setHidden:YES];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


float startX = 0;
float startY = 0;

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
    UITouch *touch = [[event allTouches] anyObject];
    
    if( [touch view] == _notePadAppDragger)
    {
        CGPoint location = [touch locationInView:self.view];
        startX = location.x - _notePadApp.center.x;
        startY = location.y - _notePadApp.center.y;
    }
    
    if( [touch view] == _webBrowserAppDragger)
    {
        CGPoint location = [touch locationInView:self.view];
        startX = location.x - _webbrowserApp.center.x;
        startY = location.y - _webbrowserApp.center.y;
    }
    
    if( [touch view] == _settingsAppDragger)
    {
        CGPoint location = [touch locationInView:self.view];
        startX = location.x - _settingsApp.center.x;
        startY = location.y - _settingsApp.center.y;
    }
    
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    if( [touch view] == _notePadAppDragger)
    {
        CGPoint location = [touch locationInView:self.view];
        location.x = location.x - startX;
        location.y = location.y - startY;
        _notePadApp.center = location;
    }
    if( [touch view] == _webBrowserAppDragger)
    {
        CGPoint location = [touch locationInView:self.view];
        location.x = location.x - startX;
        location.y = location.y - startY;
        _webbrowserApp.center = location;
    }
    if( [touch view] == _settingsAppDragger)
    {
        CGPoint location = [touch locationInView:self.view];
        location.x = location.x - startX;
        location.y = location.y - startY;
        _settingsApp.center = location;
    }
}
- (IBAction)settingsClose:(id)sender {
    _settingsStatusBarLabel.hidden = true;
    _settingsApp.hidden = true;
    [self.view endEditing:YES];
}
- (IBAction)settingsOpen:(id)sender {
    _notepadStatusBarName.hidden = true;
    _notePadApp.hidden = true;
    _webbrowserStatusBarName.hidden = true;
    _webbrowserApp.hidden = true;
    _settingsStatusBarLabel.hidden = false;
    _settingsApp.hidden = false;
    [self.view endEditing:YES];
}

- (IBAction)notePadClose:(id)sender {
    _notepadStatusBarName.hidden = true;
    _notePadApp.hidden = true;
    [self.view endEditing:YES];
}

- (IBAction)notePadOpen:(id)sender {
    _notepadStatusBarName.hidden = false;
    _notePadApp.hidden = false;
    _webbrowserStatusBarName.hidden = true;
    _webbrowserApp.hidden = true;
    _settingsStatusBarLabel.hidden = true;
    _settingsApp.hidden = true;
    [self.view endEditing:YES];
}
- (IBAction)webBrowserClose:(id)sender {
    _webbrowserStatusBarName.hidden = true;
    _webbrowserApp.hidden = true;
    [self.view endEditing:YES];
}
- (IBAction)webBrowserOpen:(id)sender {
    _webbrowserStatusBarName.hidden = false;
    _webbrowserApp.hidden = false;
    _notepadStatusBarName.hidden = true;
    _notePadApp.hidden = true;
    _settingsStatusBarLabel.hidden = true;
    _settingsApp.hidden = true;
    [self.view endEditing:YES];
}
- (IBAction)search:(id)sender {
    NSString *urlString = _urlBar.text;
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [_browser loadRequest:urlRequest];
    [loadingView setHidden:NO];
}

- (IBAction)darkModeSwitch:(UISwitch *)sender {
    if (sender.on) {
        _settingsApp.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1];
        _settingsAppDragger.backgroundColor = [UIColor colorWithWhite:0.4 alpha:0.96];
        _notePadApp.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1];
        _notePadAppDragger.backgroundColor = [UIColor colorWithWhite:0.4 alpha:0.96];
        _webbrowserApp.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1];
        _webBrowserAppDragger.backgroundColor = [UIColor colorWithWhite:0.4 alpha:0.96];
        _settingsAppDragger.tintColor = [UIColor whiteColor];
        _darkModeText.textColor = [UIColor whiteColor];
        _notepadtextview.textColor = [UIColor whiteColor];
        _notepadtextview.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1];
        _dockBar.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.90];
        _statusBar.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.90];
        _settingsStatusBarLabel.textColor = [UIColor whiteColor];
        _webbrowserStatusBarName.textColor = [UIColor whiteColor];
        _notepadStatusBarName.textColor = [UIColor whiteColor];
        _dntLabel.textColor = [UIColor whiteColor];
        _chargingLabel.textColor = [UIColor whiteColor];
        _chargingIcon.image = [UIImage imageNamed:@"charging.png"];
    } else {
        _settingsApp.backgroundColor = [UIColor colorWithWhite:1 alpha:1];
        _settingsAppDragger.backgroundColor = [UIColor colorWithWhite:0.7 alpha:0.3];
        _notePadApp.backgroundColor = [UIColor colorWithWhite:1 alpha:1];
        _notePadAppDragger.backgroundColor = [UIColor colorWithWhite:0.7 alpha:0.3];
        _webbrowserApp.backgroundColor = [UIColor colorWithWhite:1 alpha:1];
        _webBrowserAppDragger.backgroundColor = [UIColor colorWithWhite:0.7 alpha:0.3];
        _settingsAppDragger.tintColor = [UIColor blackColor];
        _darkModeText.textColor = [UIColor blackColor];
        _notepadtextview.textColor = [UIColor blackColor];
        _notepadtextview.backgroundColor = [UIColor whiteColor];
        _dockBar.backgroundColor = [UIColor colorWithWhite:0.7 alpha:0.90];
        _statusBar.backgroundColor = [UIColor colorWithWhite:0.7 alpha:0.90];
        _settingsStatusBarLabel.textColor = [UIColor blackColor];
        _webbrowserStatusBarName.textColor = [UIColor blackColor];
        _notepadStatusBarName.textColor = [UIColor blackColor];
        _dntLabel.textColor = [UIColor blackColor];
        _chargingLabel.textColor = [UIColor blackColor];
        _chargingIcon.image = [UIImage imageNamed:@"charging black.png"];
    }
}


- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [loadingView setHidden:YES];
}

- (void)checkBattery {
    [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
    float batteryLevel = [[UIDevice currentDevice] batteryLevel];
    
    batteryLevel *= 100;
    NSString *percentSign = @"%";
    _chargingLabel.text = [NSString stringWithFormat:@"%.0f%@", batteryLevel, percentSign];
    UIDeviceBatteryState deviceBatteryState = [UIDevice currentDevice].batteryState;
    if (deviceBatteryState == UIDeviceBatteryStateCharging || deviceBatteryState == UIDeviceBatteryStateFull) {
        _chargingIcon.hidden = false;
    } else {
        _chargingIcon.hidden = true;
    }
}

- (void)changeClock {
    NSDate *today = [NSDate date];
    NSDateFormatter *weekdayFormatter = [[NSDateFormatter alloc] init];
    [weekdayFormatter setDateFormat: @"EEE"];
    NSString *weekday = [weekdayFormatter stringFromDate: today];
    NSDate * now = [NSDate date];
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:@"HH:mm a"];
    NSString *newDateString = [outputFormatter stringFromDate:now];
    //_time.text = newDateString;
    _dntLabel.text = [NSString stringWithFormat:@"%@. %@", weekday, newDateString];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
