//
//  AppDelegate.m
//  miniOS
//
//  Created by Joseph on 18/3/17.
//  Copyright © 2017 JJS Digital PTY LTD. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //int screenHeight = [UIScreen mainScreen].bounds.size.height;
    //NSLog(@"Screen Height is %i", screenHeight);
    // Choose Storyboard
    UIStoryboard *storyboard = [self grabStoryboard];
    // Display Storyboard
    self.window.rootViewController = [storyboard instantiateInitialViewController];
    
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (UIStoryboard *)grabStoryboard {
    
    // Determine the screen height
    
    int screenHeight = [UIScreen mainScreen].bounds.size.height;
    UIStoryboard *storyboard;
    
    switch (screenHeight) {
            
        // iPhone 4S
        case 480:
            storyboard = [UIStoryboard storyboardWithName:@"Main4S" bundle:nil];
            break;
        // iPhone 5S
        case 568:
            storyboard = [UIStoryboard storyboardWithName:@"Main5S 5C SE" bundle:nil];
            break;
        // iPhone 6 7 6S
        case 667:
            storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            break;
        // iPhone 6 Plus 6S Plus 7 Plus
        case 736:
            storyboard = [UIStoryboard storyboardWithName:@"Main6Plus 6SPlus 7Plus" bundle:nil];
            break;
        // iPad Mini iPad Mini 2 iPad Mini 3 iPad Mini 4
        case 1024:
            storyboard = [UIStoryboard storyboardWithName:@"Main iPads other than 12.9 Inch" bundle:nil];
            break;
        // iPad Pro 12.9 Inch
        case 1366:
            storyboard = [UIStoryboard storyboardWithName:@"Main 12.9 Inch iPad Pro" bundle:nil];
            break;
            
        default:
            storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            break;
    }
    
    return storyboard;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    //self.window.rootViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"LoginScreen"];
    NSLog(@"KPP Bypassed");

}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    self.window.rootViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"LoginScreen"];
    NSLog(@"KPP Bypassed");
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
