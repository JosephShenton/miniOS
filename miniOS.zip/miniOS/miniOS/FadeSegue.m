//
//  FadeSegue.m
//  miniOS
//
//  Created by Joseph on 18/3/17.
//  Copyright © 2017 JJS Digital PTY LTD. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "FadeSegue.h"

@implementation FadeSegue
- (void)perform
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    
    [[[[[self sourceViewController] view] window] layer] addAnimation:transition
                                                               forKey:kCATransitionFade];
    
    [[self sourceViewController]
     presentViewController:[self destinationViewController]
     animated:NO completion:NULL];
}

@end
