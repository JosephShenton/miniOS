//
//  ViewController.m
//  miniOS
//
//  Created by Joseph on 18/3/17.
//  Copyright © 2017 JJS Digital PTY LTD. All rights reserved.
//

#import "ViewController.h"
#include <mach/mach_time.h>
#import <objc/message.h>
#import <dlfcn.h>
#include <sys/time.h>
#import <QuartzCore/QuartzCore.h>

@import MediaPlayer;
@import AudioToolbox;

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIImageView *profilePicture;
@property (weak, nonatomic) IBOutlet UIView *unlockView;
@property (weak, nonatomic) IBOutlet UIButton *fingerPrintButton;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *day;
@property (weak, nonatomic) IBOutlet UILabel *monthDate;
@property (weak, nonatomic) IBOutlet UILabel *batteryLebel;
@property (weak, nonatomic) IBOutlet UIImageView *chargingIcon;

@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    _profilePicture.layer.cornerRadius = 116 / 2;
    _profilePicture.layer.masksToBounds = YES;
    [[_profilePicture layer] setBorderWidth:4.5f];
    [[_profilePicture layer] setBorderColor:[UIColor whiteColor].CGColor];
    _unlockView.layer.cornerRadius = 3.6;
    _unlockView.layer.masksToBounds = YES;
    NSDate * now = [NSDate date];
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:@"HH:mm"];
    NSString *newDateString = [outputFormatter stringFromDate:now];
    _time.text = newDateString;
    NSLog(@"newDateString %@", newDateString);
    //[outputFormatter release];
    [self currentDay];
    [self currentMonthNDate];
    [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
    float batteryLevel = [[UIDevice currentDevice] batteryLevel];

    batteryLevel *= 100;
    NSString *percentSign = @"%";
    _batteryLebel.text = [NSString stringWithFormat:@"%.0f%@", batteryLevel, percentSign];
    UIDeviceBatteryState deviceBatteryState = [UIDevice currentDevice].batteryState;
    if (deviceBatteryState == UIDeviceBatteryStateCharging || deviceBatteryState == UIDeviceBatteryStateFull) {
        _chargingIcon.hidden = false;
    } else {
        _chargingIcon.hidden = true;
    }
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(changeClock) userInfo:nil repeats: YES];
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(currentDay) userInfo:nil repeats: YES];
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(currentMonthNDate) userInfo:nil repeats: YES];
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(checkBattery) userInfo:nil repeats: YES];
}

- (void)checkBattery {
    [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
    float batteryLevel = [[UIDevice currentDevice] batteryLevel];
    
    batteryLevel *= 100;
    NSString *percentSign = @"%";
    _batteryLebel.text = [NSString stringWithFormat:@"%.0f%@", batteryLevel, percentSign];
    UIDeviceBatteryState deviceBatteryState = [UIDevice currentDevice].batteryState;
    if (deviceBatteryState == UIDeviceBatteryStateCharging || deviceBatteryState == UIDeviceBatteryStateFull) {
        _chargingIcon.hidden = false;
    } else {
        _chargingIcon.hidden = true;
    }
}

- (void)currentDay {
    NSDate *now = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEEE"];
    _day.text = [dateFormatter stringFromDate:now];
    //NSLog(@"%@",[dateFormatter stringFromDate:now]);
}

- (void)currentMonthNDate {
    NSDate *currDate = [NSDate date];   //Current Date
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"MM"]; //MM will give you numeric "03", MMM will give you "Mar"
    NSString* myMonthString = [NSString stringWithFormat:@"%@", [df stringFromDate:currDate]];
    int monthNumber = [myMonthString intValue];
    NSString *monthName = [[df monthSymbols] objectAtIndex:(monthNumber-1)];
    [df setDateFormat:@"dd"];
    NSString* myDayString = [NSString stringWithFormat:@"%@", [df stringFromDate:currDate]];
    _monthDate.text = [NSString stringWithFormat:@"%@, %d", monthName, [myDayString intValue]];
}

- (void)changeClock {
    NSDate * now = [NSDate date];
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:@"HH:mm"];
    NSString *newDateString = [outputFormatter stringFromDate:now];
    _time.text = newDateString;
}

- (void)unlockMiniOS {
    NSLog(@"Unlocked");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
